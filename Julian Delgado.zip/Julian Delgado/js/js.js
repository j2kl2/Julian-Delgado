class TarjetaPago {
    constructor(id, monto, habilitada, fechaCarga, saldoAnterior) {
        this.id = id;
        this.monto = monto;
        this.habilitada = habilitada;
        this.fechaCarga = fechaCarga;
        this.saldoAnterior = saldoAnterior;
    }

    cargarMonto(monto) {
        this.monto += monto;
    }

    cambiarEstado(estado) {
        this.habilitada = estado;
    }
}

class Caja {
    constructor(id, nombre) {
        this.id = id;
        this.nombre = nombre;
        this.tarjetas = [];
    }

    agregarTarjeta(tarjeta) {
        this.tarjetas.push(tarjeta);
    }

    obtenerTarjetas() {
        return this.tarjetas;
    }

    buscarTarjetaPorId(id) {
        return this.tarjetas.find(tarjeta => tarjeta.id === id);
    }

    actualizarTabla() {
        const tbody = document.getElementById('tarjetasTableBody');
        tbody.innerHTML = '';
        this.tarjetas.forEach(tarjeta => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${tarjeta.id}</td>
                <td>${tarjeta.monto.toFixed(2)}</td>
                <td>${tarjeta.habilitada ? 'Sí' : 'No'}</td>
                <td>${tarjeta.fechaCarga}</td>
                <td>${tarjeta.saldoAnterior.toFixed(2)}</td>
            `;
            tbody.appendChild(row);
        });
    }
}

const caja = new Caja(1, 'Caja Principal');
const tarjeta1 = new TarjetaPago(123456, 10000, true, '2023-01-01', 5000);
const tarjeta2 = new TarjetaPago(256478, 15000, false, '2023-02-01', 7500);
caja.agregarTarjeta(tarjeta1);
caja.agregarTarjeta(tarjeta2);
caja.actualizarTabla();

document.getElementById('formCargarMonto').addEventListener('submit', function (e) {
    e.preventDefault();
    const tarjetaId = parseInt(document.getElementById('tarjetaId').value);
    const monto = parseFloat(document.getElementById('monto').value);
    const tarjeta = caja.buscarTarjetaPorId(tarjetaId);
    if (tarjeta) {
        tarjeta.cargarMonto(monto);
        caja.actualizarTabla();
    } else {
        alert('Tarjeta no encontrada');
    }
});

document.getElementById('habilitar').addEventListener('click', function () {
    const tarjetaId = parseInt(document.getElementById('tarjetaIdHabilitar').value);
    const tarjeta = caja.buscarTarjetaPorId(tarjetaId);
    if (tarjeta) {
        tarjeta.cambiarEstado(true);
        caja.actualizarTabla();
    } else {
        alert('Tarjeta no encontrada');
    }
});

document.getElementById('deshabilitar').addEventListener('click', function () {
    const tarjetaId = parseInt(document.getElementById('tarjetaIdHabilitar').value);
    const tarjeta = caja.buscarTarjetaPorId(tarjetaId);
    if (tarjeta) {
        tarjeta.cambiarEstado(false);
        caja.actualizarTabla();
    } else {
        alert('Tarjeta no encontrada');
    }
});
